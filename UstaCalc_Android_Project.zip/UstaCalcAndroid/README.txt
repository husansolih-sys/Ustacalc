USTACALC ANDROID PROJECT

This is a native Android WebView wrapper around the recovered UstaCalc HTML app.
The app works offline. Product prices, product standards and saved calculations
are stored locally in the app's WebView storage on the phone.

BUILD ON GITHUB (phone-friendly cloud build):
1. Create a new GitHub repository named UstaCalc.
2. Upload the CONTENTS of this folder to the repository (keep the .github folder).
3. Open the repository's Actions tab.
4. Select "Build UstaCalc APK" and tap "Run workflow" (or wait for push build).
5. Open the completed run, find Artifacts, and download "UstaCalc-APK".
6. Extract app-debug.apk on your Android phone and install it. Android may ask
   permission to install unknown apps for the browser/file manager.

Package: uz.ustacalc.app
Minimum Android: 6.0 (API 23)
